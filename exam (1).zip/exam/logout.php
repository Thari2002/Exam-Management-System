<?php

session_start();

if(isset($_SESSION['selectedID'])){
    unset($_SESSION['selectedID']);
    header('Location: login.php');
}else{
    header('Location: index.php');}

?>