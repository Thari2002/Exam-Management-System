<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "exam";

$con = new mysqli($servername, $username, $password,$database);



if($con){
    //echo "Successfully connected!";
}else{
    echo "Error!";
}
?>