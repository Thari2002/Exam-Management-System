
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Exam Center</title>
        <!-- Favicon-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top">VEC</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <?php
                          include 'admin_menu.php';
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container-fluid p-4">
             <div class="row">
                    <h1 class="masthead-heading text-uppercase mb-0 mb-4">
                        Pro
                        <span class="masthead-heading text-uppercase mb-0 ">files!</span>
                    </h1>
                </div>

                <hr class="mt-1" />
                    
                        
              <div class="row">
                <?php
                include 'conn.php';

                $sql = 
                "SELECT aname,address,email
                FROM admin";
                

                 $adminexplorer_status = mysqli_query($con,$sql);

                    while($explor_row = mysqli_fetch_assoc($adminexplorer_status)){
                ?>
                    <div class="col-md-4">
                            <h3>
                            <?php echo $explor_row['aname']; ?>
                            </h1>
                            <span class="d-none d-lg-block"><img width="100px" class="img-fluid img-profile rounded-circle mx-auto mb-2" src="pro.png" alt="..." /></span>
                            <div class="subheading mb-5">
                            <?php echo $explor_row['address']; echo " - ";
                            echo $explor_row['email']; ?> 
                            </div>
                            <div class=" mb-2 mt-4">
                                <a class="btn btn-lg btn-outline-light" name = "btnsubmit" href='profile_update.php'>
                                <i class="bi bi-pencil-fill"></i>                                    
                                Update
                                </a>
                            </div>
                    </div> 
                    <?php
                    }
                    ?>
                </div>
            <hr class="m-0" />
            </div>
        </section>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Location</h4>
                        <p class="lead mb-0">
                        Exam Center
                            <br />
                            Isurupaya B47, 10120
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Around the Web</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://twitter.com/login/"><i class="fab fa-fw fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.linkedin.com/login/"><i class="fab fa-fw fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://dribbleup.com/products/smart-basketball/default"><i class="fab fa-fw fa-dribbble"></i></a>
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">About Exam Center</h4>
                        <p class="lead mb-0">
                        EC (Examination Center) is an Examination facilitator who can be outsourced by any colleges to conduct their practical 
or written exams.
                            <br><a href="http://moe.gov.lk">Ministry Of Education Official Site</a>
                            .
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright &copy; Your Website 2021</small></div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
