<?php 
    include 'conn.php'; 

    if(!isset($_SESSION['selectedID'])){
       header('Location: admin.php');
    }
    $id = $_SESSION['selectedID'];
 
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Exam Center</title>
        <!-- Favicon-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <h1 class="mb-0">
                    Logged by
                        <span class="text-primary">
                        <?php 
                            if(isset($_SESSION['selectedName'])){
                                echo $_SESSION['selectedName'];
                            }else{
                                echo "LET the world know you!";
                            }
                        ?>
                        </span>
                    </h1>
                <a class="navbar-brand" href="#page-top"></a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#portfolio">Portfolio</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#about">Profile</a></li>
                        <ul class="navbar-nav ms-auto">
                        <?php
                          include 'admin_menu.php';
                        ?>
                    </ul>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <img class="masthead-avatar mb-5" src="assets/img/avataaars.svg" alt="..." />
                <!-- Masthead Heading-->
                <h1 class="masthead-heading text-uppercase mb-0">Admin Homepage</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-light mb-0">You are the main responsible role in the our system.</p>
            </div>
        </header>
        <!-- Portfolio Section-->
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Portfolio</h2>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Portfolio Grid Items-->
                <div class="row justify-content-center">
                    <div class="container">
                        <div class="row mt-4 mb-3">
                            <div class="col-md-3 me-5">
                                <div class="card" style="width: 18rem;background-color:tan;">
                                    <img src="https://picsum.photos/id/4/200/150" class="card-img-top" alt="...">
                                    <div class="card-body">
                                      <h5 class="card-title"><b>Lecturer Registration</b> </h5>
                                      <p class="card-text">This is the lecturers registration point. Please be identified lecturer.</p>
                                      <a href="lec_register.php" class="btn btn-primary">Go to pages</a>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 me-5">
                                <div class="card" style="width: 18rem;background-color:lightpink;">
                                    <img src="R.png" class="card-img-top" alt="..." style="height:216px;width:284px">
                                    <div class="card-body">
                                      <h5 class="card-title"><b>Students Details</b> </h5>
                                      <p class="card-text">This is the students' details editing point.</p>
                                      <a href="student_explorer.php" class="btn btn-primary">Go to pages</a>
                                    </div>
                                </div>
                            </div>

                            <!-- <div class="col-md-3 me-5">
                                <div class="card" style="width: 18rem;background-color:lightslategrey">
                                    <img src="https://picsum.photos/id/136/200/150" class="card-img-top" alt="...">
                                    <div class="card-body">
                                      <h5 class="card-title"><b>Exam Details</b> </h5>
                                      <p class="card-text">This is the lecturers registration point. Please be identified lecturer.</p>
                                      <a href="lec_register.php" class="btn btn-primary">Go to pages</a>
                                    </div>
                                </div>
                            </div> -->

                            <div class="col-md-3 me-5">
                                <div class="card" style="width: 18rem;background-color:lightgreen;">
                                    <img src="https://picsum.photos/id/5/200/150" class="card-img-top" alt="...">
                                    <div class="card-body">
                                      <h5 class="card-title"><b>Admins</b> </h5>
                                      <p class="card-text">This is the Admins point. who are the registerd admins.</p>
                                      <a href="admin_explorer.php" class="btn btn-primary">Go to pages</a>
                                    </div>
                                </div>  
                            </div>
                        </div>
                    </div><br><br> 
                </div>
            </div>
        </section>
        <!-- About Section-->
        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">Profile</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div class="row ">
                    <div class="col-md-3 offset-md-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Contact</h3>
                            <div class="subheading mb-1">Name</div>
                            <div><?php if(isset($_SESSION['selectedName'])){ echo $_SESSION['selectedName'];}else{echo "<a href='login.php'>Login</a>";} ?></div><br>
                            <div class="subheading mb-1">Mobile</div>
                            <div><?php if(isset($_SESSION['selectedContact'])){ echo $_SESSION['selectedContact'];}else{echo "<a href='login.php'>Login</a>";} ?></div>
                            <div class="subheading mb-1 mt-4">Email</div>
                            <div><?php if(isset($_SESSION['selectedUser'])){ echo $_SESSION['selectedUser'];}else{echo "<a href='login.php'>Login</a>";} ?></div>
                            <div class="subheading mb-1 mt-4">Address</div>
                            <div><?php if(isset($_SESSION['selectedAddress'])){ echo $_SESSION['selectedAddress'];}else{echo "<a href='login.php'>Login</a>";} ?></div>
                            <a href='profile_update.php?id = ".$_SESSION["selectedID"]."'>Edit</a></td>
                        </div>
                    </div>
                    
                </div>
                <!-- About Section Button-->
                <div class="text-center mt-4">
                    <a class="btn btn-xl btn-outline-light" href='profile_update.php'>
                    <i class="bi bi-pencil-fill"></i>
                        Update
                    </a>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Location</h4>
                        <p class="lead mb-0">
                        Exam Center
                            <br />
                            Isurupaya B47, 10120
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Around the Web</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://twitter.com/login/"><i class="fab fa-fw fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.linkedin.com/login/"><i class="fab fa-fw fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://dribbleup.com/products/smart-basketball/default"><i class="fab fa-fw fa-dribbble"></i></a>
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">About Exam Center</h4>
                        <p class="lead mb-0">
                        EC (Examination Center) is an Examination facilitator who can be outsourced by any colleges to conduct their practical 
or written exams.
                            <br><a href="http://moe.gov.lk">Ministry Of Education Official Site</a>
                            .
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright &copy; Your Website 2021</small></div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
