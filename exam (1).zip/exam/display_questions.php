<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Exam Center</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>

<section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container-fluid p-4">
             <div class="row">
                    <h1 class="masthead-heading text-uppercase mb-0 mb-4">
                        Please
                        <span class="masthead-heading text-uppercase mb-0 ">Anserw for Your Exams</span>
                    </h1>
                </div>

                <hr class="mt-1" />
                    
                        
              <div class="row">
                <?php
                include 'conn.php';

                $sql = 
                "SELECT Ename, question1, question2, question3, question4, question5 FROM add_exam";
                

                 $explorer_status = mysqli_query($con,$sql);

                    while($explor_row = mysqli_fetch_assoc($explorer_status)){
                        ?>
                    <div class="col-md-4">
                            <h3>
                            <?php echo $explor_row['Ename']; echo "<br>"; ?>
                            </h1>
                            <!-- <span class="d-none d-lg-block"><img width="100px" class="img-fluid img-profile rounded-circle mx-auto mb-2" src="pro.png" alt="..." /></span> -->
                            <div class="subheading mb-5">
                            <?php echo $explor_row['question1'];echo "<br>";
                            echo $explor_row['question2'];echo "<br>";
                            echo $explor_row['question3'];echo "<br>";
                            echo $explor_row['question4'];echo "<br>";
                            echo $explor_row['question5'];
                            ?> 
                            </div>
                            <!-- <div class=" mb-2 mt-4">
                                
                                <a class="btn btn-lg btn-outline-light" name = "btnsubmit" href='view.php'>
                                    <i class="fas fa-download me-2"></i>
                                    Update
                                </a>
                            </div> -->
                    </div> 
                    <?php
                    }
                    ?>
                </div>
            <hr class="m-0" />
            </div>
        </section>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
